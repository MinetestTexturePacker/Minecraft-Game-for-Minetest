Adds tin, silver and technic materials to 3d_armor.
Requires technic mod to be installed for craft registration.

Depends: 3d_armor

Source code and textures by poet.nohit
