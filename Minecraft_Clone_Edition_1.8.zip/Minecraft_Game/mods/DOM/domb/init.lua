domb = {}

--DOM base system library
dofile(minetest.get_modpath("domb").."/domb.lua")

DOM_registra_comandos_de_uso_geral()
